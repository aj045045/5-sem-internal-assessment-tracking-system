from .Database import Database

class Subject(Database,):
    def add():
        return

    def update():
        return

    def delete():
        return

    def view():
        return

"""
#REVIEW - Create all collection for data entry
userData = ["user","semester","student","course","subject","assignment","assessment_type","assessment","exam_type","faculty","paper","result"]
for data in userData:
    userCreateData.create_collection(data)
"""